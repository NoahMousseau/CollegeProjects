void calculateCirclePerimeterStruct(struct CircleStr& circle);
void calculateCircleAreaStruct(struct CircleStr& circle);

struct CircleStr{
	float radius, perimeter, area;
};